<?php
/* this PHP stub serves to block people from accessing this folder directly. */
header("Location:../..");

