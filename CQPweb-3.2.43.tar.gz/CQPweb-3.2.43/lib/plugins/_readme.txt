This directory is for plugins.

Plugins can be used for very configurable tasks - like tagging text, or transliterating query results into a different
alphabet.

You will find some example plugins are already here - they are supplied alongside CQPweb.

The 'contrib' folder contains plugins provided by others. To make them usable, move them to this folder (or, create 
a symlink). 

The plugin system is explained in detail in the CQPweb System Administrator's manual.
