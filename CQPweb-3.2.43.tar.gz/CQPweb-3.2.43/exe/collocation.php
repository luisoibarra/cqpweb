<?php require('../lib/collocation-ui.php');
