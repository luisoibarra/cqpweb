<?php require ('../lib/lgcurve-act.php');
