<?php require('../lib/queryhome.php'); 
