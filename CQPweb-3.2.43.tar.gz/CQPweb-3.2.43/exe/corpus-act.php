<?php require ('../lib/corpus-act.php');
