/*  $Revision: 1.1 $
**
**  Editline system header file for OS-9 (on 68k).
*/

#define CRLF		"\r\l"
#define FORWARD		extern

#include <dir.h>
typedef struct direct	DIRENTRY;
